SvConfig = {}

-- Add a discord bot token if you want the user's discord avatar to show in the menu
-- I recommend creating a new discord bot for this purpose
SvConfig.discordBotToken = 'TOKEN_HERE'